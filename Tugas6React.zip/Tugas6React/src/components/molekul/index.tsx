import Header from './Header';
import MainSection from './MainSection';
import AboutUs from './About Us';
import Footer from './Footer';

export {Header, MainSection, AboutUs,Footer}