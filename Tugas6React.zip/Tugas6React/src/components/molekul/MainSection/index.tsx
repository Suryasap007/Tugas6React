import React from 'react';
import './MainSection.css';

const MainSection = () => {
  return (
    <section className="main">
        <div className="container">
            <div className="main__wrapper">
                <h1>Hello, we're gtd.</h1>
            </div>
        </div>
    </section>
  )
}

export default MainSection;