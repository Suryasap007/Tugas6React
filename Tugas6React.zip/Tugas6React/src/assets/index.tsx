import LogoGTD from './image/gtd_logo.png';
import ImageHero from './image/img_hero.jpg'
import DanielCircle from './image/img_danielle_circle.png';
import BrianCircle from './image/img_brian_circle.png';
import LisaCircle from './image/img_lisa_circle.png';


export {LogoGTD, ImageHero, DanielCircle, BrianCircle,LisaCircle};