import React from 'react';
import './App.css';
import MainApp from './MainApp';

function App() {
  return (
    <MainApp/>
  );
}

export default App;
